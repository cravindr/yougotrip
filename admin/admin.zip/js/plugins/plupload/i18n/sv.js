﻿// .po file like language pack
plupload.addI18n({
	'Select files' : 'Välj filer',
	'Add files to the upload queue and click the start button.' : 'Lägg till filer till kön och tryck på start.',
	'Filename' : 'Filnamn',
	'Status' : 'Status',
	'Size' : 'Storlek',
	'Add files' : 'Lägg till filer',
	'Stop current upload' : 'Stoppa uppladdningen',
	'Start uploading queue' : 'Starta uppladdningen',
	'Drag files here.' : 'Dra filer hit'
});