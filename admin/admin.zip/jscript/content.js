// JavaScript Document

    var homecont = CKEDITOR.replace('homecont');
	CKEDITOR.disableAutoInline = true;
    
	var aboutus = CKEDITOR.replace('aboutus');
	CKEDITOR.disableAutoInline = true;
	
	var services = CKEDITOR.replace('services');
	CKEDITOR.disableAutoInline = true;
	
	var contactus = CKEDITOR.replace('contactus');
	CKEDITOR.disableAutoInline = true;
	
	var termsandcondition = CKEDITOR.replace('termsandcondition');
	CKEDITOR.disableAutoInline = true;
	
	var returnpol = CKEDITOR.replace('returnpol');
	CKEDITOR.disableAutoInline = true;
	
    var invoice = CKEDITOR.replace('invoice_message');
	CKEDITOR.disableAutoInline = true;
	
	var welcome = CKEDITOR.replace('welcome');
	CKEDITOR.disableAutoInline = true;
	
	var forgetpass = CKEDITOR.replace('forgetpass');
	CKEDITOR.disableAutoInline = true;
	
	var activationmessage = CKEDITOR.replace('activationmessage');
	CKEDITOR.disableAutoInline = true;
	
  
  
  
	
		