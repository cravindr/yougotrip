// JavaScript Document

    var businesshour = CKEDITOR.replace('businesshour');
	CKEDITOR.disableAutoInline = true;
    
	var stayconnected = CKEDITOR.replace('stayconnected');
	CKEDITOR.disableAutoInline = true;
	
	var visaprocessing = CKEDITOR.replace('visaprocessing');
	CKEDITOR.disableAutoInline = true;
	
	var ticketbooking = CKEDITOR.replace('ticketbooking');
	CKEDITOR.disableAutoInline = true;
	
	var whyweare = CKEDITOR.replace('whyweare');
	CKEDITOR.disableAutoInline = true;
	
	
  
  
	
		