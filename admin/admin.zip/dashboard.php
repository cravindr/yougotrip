<?php
require('smartysetting.php');

$smarty->display('header.tpl');
$smarty->display('dashboard.tpl');
$smarty->display('footer.tpl');
?>
